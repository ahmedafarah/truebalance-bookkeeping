
# TrueBalance Bookkeeping LLC Website

## Custom Domain
www.truebalance-bookkeeping.net

## How to Publish
1. Create a GitHub repo and upload all files from this zip.
2. Push to `main` branch.
3. Enable GitHub Pages via Actions in Settings → Pages.
4. DNS: Add CNAME for `www` pointing to `ahmedafarah.github.io`.
5. Enable HTTPS after DNS propagates.
